DEFAULT JEN — DIRECT FILE LOADING

1. Extract this ZIP. Start by loading JEN_START_HERE.md and asking the chat to use it as Jen's profile.
2. Add the CQ_ARCHIVE_*.md files as reference material where your chat, project or existing GPT supports knowledge files. Follow that product's current file and account limits.
3. Ask a source-specific question and verify the answer cites the episode and a passage. File upload is not proof that every passage was read.
4. Re-download a new export after archive updates; these files do not synchronize automatically.

This export has 6 archive packs plus the profile. It includes all 318 catalog entries, of which 318 have text.
EXPORT_MANIFEST.json lists coverage, sources, hashes, and token counts in two reference tokenizers. Product tokenization may differ.
Source repository: https://github.com/johnnyiucci-eng/collectors-quest-jen
